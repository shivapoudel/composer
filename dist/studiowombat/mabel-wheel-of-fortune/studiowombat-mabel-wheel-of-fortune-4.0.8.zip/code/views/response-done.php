<?php
/** @var \MABEL_WOF\Code\Models\Wheel_Model $model */
?>
<button class="wof-btn-done wof-close">
	<?php _e($model->setting_or_default('button_done','Close this')) ?>
</button>