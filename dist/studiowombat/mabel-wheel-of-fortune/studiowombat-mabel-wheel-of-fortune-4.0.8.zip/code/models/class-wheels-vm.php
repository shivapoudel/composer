<?php

namespace MABEL_WOF\Code\Models {

	class Wheels_VM
	{
		public $wheels;

		public function __construct() {
			$this->wheels = [];
		}

	}
}