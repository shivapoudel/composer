<?php

namespace MABEL_WOF\Code\Models {

	class Wheel_Shortcode_VM {

		public $wheel;

	}
}
