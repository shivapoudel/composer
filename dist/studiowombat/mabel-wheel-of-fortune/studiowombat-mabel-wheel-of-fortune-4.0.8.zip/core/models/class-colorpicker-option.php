<?php

namespace MABEL_WOF\Core\Models {

	class ColorPicker_Option extends Option
	{

	}
}