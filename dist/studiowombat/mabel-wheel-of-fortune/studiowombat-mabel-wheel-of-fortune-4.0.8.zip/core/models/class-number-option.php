<?php

namespace MABEL_WOF\Core\Models {

	class Number_Option extends Text_Option
	{
        public $min;
        public $max;
	}
}