<?php

namespace MABEL_WOF\Core\Models {

	class Hidden_Option extends Option
	{

	}
}