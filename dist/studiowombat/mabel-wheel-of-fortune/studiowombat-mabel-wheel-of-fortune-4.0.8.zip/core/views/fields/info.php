<?php
/** @var \MABEL_WOF\Core\Models\Info_Option $option */
if(!defined('ABSPATH')){
	die;
}
?>

<p class="t-c">
	<?php _e($option->text); ?>
</p>