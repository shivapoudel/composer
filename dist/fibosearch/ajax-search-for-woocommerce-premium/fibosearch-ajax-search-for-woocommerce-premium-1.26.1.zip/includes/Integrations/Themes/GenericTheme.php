<?php

namespace DgoraWcas\Integrations\Themes;

use DgoraWcas\Abstracts\ThemeIntegration;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GenericTheme extends ThemeIntegration {
}
