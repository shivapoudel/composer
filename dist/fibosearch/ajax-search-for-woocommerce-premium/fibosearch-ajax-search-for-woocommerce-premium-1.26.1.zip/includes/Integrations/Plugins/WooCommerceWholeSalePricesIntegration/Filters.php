<?php
/**
 * @dgwt_wcas_premium_only
 */

namespace DgoraWcas\Integrations\Plugins\WooCommerceWholeSalePricesIntegration;

use DgoraWcas\Engines\TNTSearchMySQL\Config;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Filters {
	public $plugin_names = array(
		'woocommerce-wholesale-prices-premium/woocommerce-wholesale-prices-premium.bootstrap.php',
	);

	private $visible_products  = array();
	private $hidden_categories = array();

	public function init() {
		foreach ( $this->plugin_names as $plugin_name ) {
			if ( Config::isPluginActive( $plugin_name ) ) {
				$this->getSessionData();
				$this->excludeHiddenProductsAndCategories();

				break;
			}
		}
	}

	/**
	 * Set visible products and hidden categories from PHP Session
	 *
	 * @return void
	 */
	private function getSessionData() {
		if ( ! session_id() ) {
			session_start();
		}

		if ( ! empty( $_SESSION['dgwt-wcas-wcwsp-visible-products'] ) ) {
			$this->visible_products = $_SESSION['dgwt-wcas-wcwsp-visible-products'];
		}
		if ( ! empty( $_SESSION['dgwt-wcas-wcwsp-hidden-categories'] ) ) {
			$this->hidden_categories = $_SESSION['dgwt-wcas-wcwsp-hidden-categories'];
		}
	}

	/**
	 * Include only products and categories returned by WooCommerce Wholesale Prices plugin
	 */
	private function excludeHiddenProductsAndCategories() {
		add_filter( 'dgwt/wcas/tnt/search_results/ids', function ( $ids ) {
			if ( ! empty( $this->visible_products ) && is_array( $this->visible_products ) ) {
				$ids = array_intersect( $ids, $this->visible_products );
			}

			return $ids;
		} );

		add_filter( 'dgwt/wcas/search_results/term_ids', function ( $ids ) {
			// Exclude hidden categories.
			if ( ! empty( $this->hidden_categories ) && is_array( $this->hidden_categories ) ) {
				$ids = array_diff( $ids, $this->hidden_categories );
			}

			return $ids;
		} );
	}
}
