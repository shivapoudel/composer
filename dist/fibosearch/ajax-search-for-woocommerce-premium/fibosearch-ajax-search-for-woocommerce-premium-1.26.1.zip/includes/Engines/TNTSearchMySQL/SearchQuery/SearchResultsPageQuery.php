<?php

namespace DgoraWcas\Engines\TNTSearchMySQL\SearchQuery;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SearchResultsPageQuery extends MainQuery {

	public function __construct() {

		parent::__construct();

	}

}
