<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<tr class="js-dgwt-wcas-search-page-row">
	<td><?php echo $i; ?></td>
	<td><?php echo esc_html( $row['phrase'] ); ?></td>
	<td><?php echo esc_html( $row['qty'] ); ?></td>
</tr>
