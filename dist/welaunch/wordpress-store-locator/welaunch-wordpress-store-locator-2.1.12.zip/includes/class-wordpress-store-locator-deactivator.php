<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://welaunch.io/plugins
 * @since      1.0.0
 *
 * @package    WordPress_Store_Locator
 * @subpackage WordPress_Store_Locator/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    WordPress_Store_Locator
 * @subpackage WordPress_Store_Locator/includes
 * @author     Daniel Barenkamp <contact@db-dzine.de>
 */
class WordPress_Store_Locator_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
