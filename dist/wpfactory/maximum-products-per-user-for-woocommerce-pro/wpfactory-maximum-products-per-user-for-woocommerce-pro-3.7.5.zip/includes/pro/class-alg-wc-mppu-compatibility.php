<?php
/**
 * Maximum Products per User for WooCommerce - Compatibility.
 *
 * @version 3.6.9
 * @since   3.6.0
 * @author  WPFactory
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists( 'Alg_WC_MPPU_Compatibility' ) ) :

	class Alg_WC_MPPU_Compatibility {

		/**
		 * Constructor.
		 *
		 * @version 3.6.9
		 * @since   3.6.0
		 */
		function __construct() {
			// Point of sale for WooCommerce (https://woocommerce.com/document/point-of-sale/).
			add_filter( 'woocommerce_rest_pre_insert_shop_order_object', array( $this, 'check_cart_quantities_via_rest' ), 10, 3 );
			// WPC Composite products.
			add_filter( 'wooco_product_single_add_to_cart_text', array( $this, 'change_add_to_cart_btn_text' ), 10, 2 );
			add_filter( 'wooco_product_add_to_cart_text', array( $this, 'change_add_to_cart_btn_text' ), 10, 2 );
		}

		/**
		 * change_add_to_cart_btn_text.
		 *
		 * @version 3.6.9
		 * @since   3.6.9
		 *
		 * @param $text
		 * @param $product
		 *
		 * @return string
		 */
		function change_add_to_cart_btn_text( $text, $product ) {
			if ( 'yes' === get_option( 'alg_wc_mppu_wpccp_change_add_to_cart_btn_text_from_guest_users', 'no' ) ) {
				$text = alg_wc_mppu()->pro->change_add_to_cart_btn_text( $text, $product );
			}
			return $text;
		}

		/**
		 * check_cart_quantities_via_rest.
		 *
		 * @see https://woocommerce.com/document/point-of-sale/
		 *
		 * @version 3.6.1
		 * @since   3.6.0
		 *
		 * @param $order
		 * @param $request
		 * @param $creating
		 *
		 * @return WP_Error | WC_Order
		 */
		function check_cart_quantities_via_rest( $order, $request, $creating ) {
			if ( 'yes' === get_option( 'alg_wc_mppu_pos_wc_registers_check_limits', 'no' ) ) {
				$order_item_quantities = alg_wc_mppu()->core->get_order_item_quantities( $order );
				foreach ( $order->get_items() as $item_id => $item ) {
					$product = $item->get_product();
					if ( ! alg_wc_mppu()->core->check_quantities_for_product( $product->get_id(), array(
						'_cart_item_quantity'  => $item->get_quantity(),
						'do_add_notices'       => true,
						'current_user_id'      => $order->get_user_id(),
						'cart_item_quantities' => $order_item_quantities,
						'return_notices'       => true
					) ) ) {
						if ( 'yes' !== get_option( 'alg_wc_mppu_multiple_notices', 'yes' ) ) {
							break;
						}
					}
				}
				if ( count( $error_msgs = alg_wc_mppu()->core->get_error_messages() ) > 0 ) {
					$error = new WP_Error();
					foreach ( $error_msgs as $index => $error_msg ) {
						$error->add( "alg_mppu_create_order_rest_error", $error_msg );
					}
					return $error;
				}
			}
			return $order;
		}

		/**
		 * Checks if a user has a active membership level from the WordPress Membership Plugin (https://simple-membership-plugin.com/).
		 *
		 * @version 3.6.8
		 * @since   3.6.8
		 *
		 * @param $user_id
		 * @param $membership_level_id
		 *
		 * @return bool
		 */
		function swpm_is_user_active_on_membership( $user_id, $membership_level_id ) {
			global $wpdb;
			$user     = get_user_by( 'ID', $user_id );
			$query_db = $wpdb->get_row( $wpdb->prepare( "SELECT member_id FROM {$wpdb->prefix}swpm_members_tbl WHERE email = %s and membership_level = %d and account_state = %s", $user->user_email, $membership_level_id, 'active' ) );
			return ! empty( $query_db );
		}
	}

endif;

return new Alg_WC_MPPU_Compatibility();