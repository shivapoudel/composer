<?php
/**
 * Maximum Products per User for WooCommerce - Orders above limits.
 *
 * @version 3.6.1
 * @since   3.6.1
 * @author  WPFactory
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists( 'Alg_WC_MPPU_Orders_Above_Limits' ) ) :

	class Alg_WC_MPPU_Orders_Above_Limits {

		/**
		 * Constructor.
		 *
		 * @version 3.6.1
		 * @since   3.6.1
		 */
		function __construct() {
			add_filter( 'init', array( $this, 'register_post_status' ) );
			add_filter( 'wc_order_statuses', array( $this, 'create_order_status' ) );
			add_action( 'woocommerce_checkout_create_order', array( $this, 'set_session_variable' ), 10, 2 );
			add_action( 'woocommerce_thankyou', array( $this, 'change_new_order_status' ), PHP_INT_MAX );
			add_filter( 'alg_wc_mppu_output_notices_args', array( $this, 'display_checkout_messages_as_notices_instead_of_errors' ) );
		}

		/**
		 * display_checkout_messages_as_notices_instead_of_errors.
		 *
		 * @version 3.6.1
		 * @since   3.6.1
		 *
		 * @param $args
		 *
		 * @return mixed
		 */
		function display_checkout_messages_as_notices_instead_of_errors( $args ) {
			if (
				( function_exists( 'is_checkout' ) && is_checkout() ) &&
				'yes' === get_option( 'alg_wc_mppu_orders_above_limits_allowed', 'no' )
			) {
				$args['notice_type'] = 'notice';
			}
			return $args;
		}

		/**
		 * set_session_variable.
		 *
		 * @see WC_Checkout::create_order
		 *
		 * @version 3.6.1
		 * @since   3.6.1
		 *
		 * @param $order
		 * @param $data
		 */
		function set_session_variable( $order, $data ) {
			if (
				'yes' === get_option( 'alg_wc_mppu_orders_above_limits_allowed', 'no' ) &&
				'yes' === get_option( 'alg_wc_mppu_orders_above_limits_change_status', 'no' )
			) {
				alg_wc_mppu()->core->check_quantities( array( 'return_notices' => true ) );
				$errors = alg_wc_mppu()->core->error_messages;
				if ( ! empty( $errors ) ) {
					WC()->session->set( 'alg_wc_mppu_order_above_limit', array( 'order' => $order, 'data' => $data ) );
				}
			}
		}

		/**
		 * change_new_order_status.
		 *
		 * @version 3.6.1
		 * @since   3.6.1
		 */
		function change_new_order_status( $order_id ) {
			if (
				'yes' === get_option( 'alg_wc_mppu_orders_above_limits_allowed', 'no' ) &&
				'yes' === get_option( 'alg_wc_mppu_orders_above_limits_change_status', 'no' ) &&
				$order_id &&
				! empty( $order = wc_get_order( $order_id ) ) &&
				! empty( $above_limit_order_info = WC()->session->get( 'alg_wc_mppu_order_above_limit' ) ) &&
				! empty( $above_limit_order_status = get_option( 'alg_wc_mppu_orders_above_limits_status', 'wc-mppu-invalid' ) )
			) {
				if ( $above_limit_order_status !== $order->get_status() ) {
					$order->update_status( $above_limit_order_status );
				}
				WC()->session->__unset( 'alg_wc_mppu_order_above_limit' );
			}
		}

		/**
		 * register_post_status.
		 *
		 * @version 3.6.1
		 * @since   3.6.1
		 */
		function register_post_status() {
			if (
				'yes' === get_option( 'alg_wc_mppu_orders_above_limits_change_status', 'no' )
			) {
				register_post_status( 'wc-mppu-invalid', array(
					'label'                     => get_option( 'alg_wc_mppu_orders_above_limits_custom_status_label', __( 'Above limit', 'maximum-products-per-user-for-woocommerce' ) ),
					'public'                    => true,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
				) );
			}
		}

		/**
		 * create_order_status.
		 *
		 * @version 3.6.1
		 * @since   3.6.1
		 *
		 * @param $order_statuses
		 *
		 * @return mixed
		 */
		function create_order_status( $order_statuses ) {
			if (
				'yes' === get_option( 'alg_wc_mppu_orders_above_limits_change_status', 'no' )
			) {
				$order_statuses['wc-mppu-invalid'] = get_option( 'alg_wc_mppu_orders_above_limits_custom_status_label', __( 'Above limit', 'maximum-products-per-user-for-woocommerce' ) );
			}
			return $order_statuses;
		}
	}

endif;

return new Alg_WC_MPPU_Orders_Above_Limits();