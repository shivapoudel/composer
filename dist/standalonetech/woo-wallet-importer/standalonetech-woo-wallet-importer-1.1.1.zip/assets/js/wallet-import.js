/*global ajaxurl, woo_wallet_importer_param */
;
(function ($, window) {

    /**
     * walletImportForm handles the import process.
     */
    var walletImportForm = function ($form) {
        this.$form = $form;
        this.xhr = false;
        this.position = 2;
        this.file = woo_wallet_importer_param.file;
        this.delimiter = woo_wallet_importer_param.delimiter;
        this.security = woo_wallet_importer_param.import_nonce;
        this.import_id = woo_wallet_importer_param.import_id;

        // Number of import successes/failures.
        this.imported = 0;
        this.failed = 0;

        // Initial state.
        this.progressbar = this.$form.find('.woo-wallet-importer-progress');
        this.spinner = this.$form.find('.spinner');
        this.progressbar.progressbar("option", {value: 0});

        this.run_import = this.run_import.bind(this);

        // Start importing.
        this.run_import();
    };

    /**
     * Run the import in batches until finished.
     */
    walletImportForm.prototype.run_import = function () {
        var $this = this;

        $.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {
                action: 'woo_wallet_do_ajax_import',
                position: $this.position,
                file: $this.file,
                delimiter: $this.delimiter,
                security: $this.security,
                import_id: $this.import_id,
                imported: $this.imported,
                failed : $this.failed,
            },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    $this.position = response.data.position;
                    $this.imported = response.data.imported;
                    $this.failed = response.data.failed;
                    $this.progressbar.progressbar("option", {value: response.data.percentage});

                    if ('done' === response.data.position) {
                        $this.spinner.removeClass('is-active');
                        //window.location = response.data.url + '&imported=' + parseInt( $this.imported, 10 ) + '&failed=' + parseInt( $this.failed, 10 );
                        window.location = response.data.url;
                    } else {
                        $this.run_import();
                    }
                }
            }
        }).fail(function (response) {
            window.console.log(response);
        });
    };

    /**
     * Function to call walletImportForm on jQuery selector.
     */
    $.fn.woo_wallet_importer = function () {
        new walletImportForm(this);
        return this;
    };
    $(".woo-wallet-importer-progress").progressbar({value: false});
    $('.woo-wallet-importer').woo_wallet_importer();
    

})(jQuery, window);
