/* global woo_wallet_importer_admin_param */

jQuery(function ($) {
    var $wallet_screen = $('.toplevel_page_woo-wallet'),
            $title_action = $wallet_screen.find('.wrap h2:first');
    $title_action.html($title_action.html() + ' <a href="' + woo_wallet_importer_admin_param.import_url + '" class="page-title-action">' + woo_wallet_importer_admin_param.title + '</a>');
});