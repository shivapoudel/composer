<?php
/**
 * Plugin Name: TeraWallet Importer
 * Plugin URI: https://standalonetech.com/
 * Description: Import wallet transactions from a CSV file.
 * Author: StandaloneTech
 * Author URI: https://standalonetech.com/
 * Version: 1.1.1
 * Requires at least: 4.4
 * Tested up to: 5.4
 * WC requires at least: 3.0
 * WC tested up to: 5.1
 * 
 * Text Domain: woo-wallet-importer
 * Domain Path: /languages/
 */
if (!defined('IMPORT_DEBUG')) {
    /** Display verbose errors */
    define('IMPORT_DEBUG', false);
}

// Load Importer API
require_once ABSPATH . 'wp-admin/includes/import.php';

if (!class_exists('WP_Importer')) {
    $class_wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
    if (file_exists($class_wp_importer)) {
        require $class_wp_importer;
    }
}
if (!class_exists('WOO_Wallet_Importer_Helper')) {
    require dirname(__FILE__) . '/class-woo-wallet-importer-helper.php';
}

/**
 * WordPress Importer class for managing the import process of a WXR file
 *
 * @package WordPress
 * @subpackage Importer
 */
if (class_exists('WP_Importer')) {

    class Woo_Wallet_CSV_Import extends WP_Importer {

        /** Sheet columns
         * @value array
         */
        public $column_indexes = array();
        public $column_keys = array();

        public function __construct() {
            add_action('admin_enqueue_scripts', array($this, 'woo_wallet_csv_import_scripts'), 10);
        }

        public function woo_wallet_csv_import_scripts() {
            $wp_scripts = wp_scripts();
            wp_register_style('woo-wallet-import-jquery-ui', '//ajax.googleapis.com/ajax/libs/jqueryui/' . $wp_scripts->registered['jquery-ui-core']->ver . '/themes/smoothness/jquery-ui.css', false, $wp_scripts->registered['jquery-ui-core']->ver, false);
            wp_register_script('woo_wallet_importer', woo_wallet_importer()->plugin_url() . '/assets/js/wallet-import.js', array('jquery'), rand(), true);
        }

        // dispatcher
        public function dispatch() {
            if (empty($_GET['step'])) {
                $step = 0;
            } else {
                $step = (int) $_GET['step'];
            }
            $this->header($step);
            switch ($step) {
                case 0 :
                    $this->greet();
                    break;
                case 1 :
                    check_admin_referer('import-upload');
                    set_time_limit(0);
                    echo '<div class="wc-progress-form-content woocommerce-importer woocommerce-importer__importing">';
                    $result = $this->import();
                    echo '</div>';
                    if (is_wp_error($result)) {
                        echo $result->get_error_message();
                    }
                    break;
                case 2:
                    $this->success();
                    break;
            }

            $this->footer();
        }

        // User interface wrapper start
        public function header($step) {
            ?>
            <style type="text/css">
                .woocommerce-exporter-wrapper .wc-progress-steps li, .woocommerce-importer-wrapper .wc-progress-steps li, .woocommerce-progress-form-wrapper .wc-progress-steps li{
                    width: 33.3%;
                }
            </style>
            <?php
            echo '<div class="wrap woocommerce">';
            echo '<h1>' . __('Import Wallet Transactions', 'woo-wallet-importer') . '</h1>';
            echo '<div class="woocommerce-progress-form-wrapper">';
            echo '<ol class="wc-progress-steps">';
            ?>
            <li class="<?php echo $step === 0 || $step === 1 || $step === 2 ? 'active' : ''; ?>"><?php _e('Upload CSV file', 'woo-wallet-importer'); ?></li>
            <li class="<?php echo $step === 1 || $step == 2 ? 'active' : ''; ?>"><?php _e('Import', 'woo-wallet-importer'); ?></li>
            <li class="<?php echo $step === 2 ? 'active' : ''; ?>"><?php _e('Done!', 'woo-wallet-importer'); ?></li>
            <?php
            echo '</ol>';
        }

        // User interface wrapper end
        public function footer() {
            echo '</div>';
            echo '</div>';
        }

        // Step 1
        public function greet() {
            $action = add_query_arg('step', 1);
            $bytes = apply_filters('import_upload_size_limit', wp_max_upload_size());
            $size = size_format($bytes);
            $upload_dir = wp_upload_dir();
            if (!empty($upload_dir['error'])) :
                ?>
                <div class="error"><p><?php _e('Before you can upload your import file, you will need to fix the following error:'); ?></p>
                    <p><strong><?php echo $upload_dir['error']; ?></strong></p></div>
                <?php
            else :
                ?>
                <form enctype="multipart/form-data" id="import-upload-form" method="post" class="wc-progress-form-content woocommerce-importer" action="<?php echo esc_url(wp_nonce_url($action, 'import-upload')); ?>">
                    <header>
                        <h2><?php _e('Import wallet transactions from a CSV file', 'woo-wallet-importer'); ?></h2>
                        <p><?php _e('This tool allows you to import wallet transactions to user accounts from a CSV file.', 'woo-wallet-importer'); ?></p>
                    </header>
                    <section>
                        <table class="form-table woocommerce-importer-options">
                            <tbody>
                                <tr>
                                    <th>
                                        <?php
                                        printf(
                                                '<label for="upload">%s</label>',
                                                __('Choose a file from your computer:')
                                        );
                                        ?>
                                    </th>
                                    <td>
                                        <input type="file" id="upload" name="import" size="25" />
                                        <br>
                                        <small><?php echo sprintf(__('Maximum size: %s'), $size); ?></small>
                                        <br>
                                        <small><a download="sample.csv" href="<?php echo untrailingslashit(plugins_url('/', __FILE__)) . '/sample.csv'; ?>"><?php _e('Download Sample CSV', 'woo-wallet-importer'); ?></a></small>
                                        <input type="hidden" name="action" value="save" />
                                        <input type="hidden" name="max_file_size" value="<?php echo $bytes; ?>" />
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </section>
                    <div class="wc-actions">
                        <?php submit_button(__('Upload file and import'), 'primary'); ?>
                    </div>
                </form>
            <?php
            endif;
        }

        public function success() {
            ?>
            <div class="wc-progress-form-content woocommerce-importer">
                <section class="woocommerce-importer-done">
                    <?php _e('Import complete!', 'woo-wallet-importer'); ?>
                    <?php
                    if (isset($_REQUEST['failed']) && $_REQUEST['failed']) {
                        echo sprintf(__('Failed to import <strong>%s</strong> transactions.', 'woo-wallet-importer'), $_REQUEST['failed']);
                    }
                    ?>
                    <a href="#" class="woo-wallet-importer-done-view-errors">View import log</a>
                </section>

                <section class="woo-wallet-importer-error-log" style="display: none;padding-bottom: 24px;">
                    <table class="widefat woo-wallet-importer-error-log-table">
                        <thead>
                            <tr>
                                <th><?php _e('Transaction Logs', 'woo-wallet-importer'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $import_id = $_REQUEST['import_id'];
                            $messages = get_transient("woo_wallet_import_messages_{$import_id}");
                            if ($messages) {
                                foreach ($messages as $message):
                                    ?>
                                    <tr>
                                        <td><?php echo $message; ?></td>
                                    </tr>
                                    <?php
                                endforeach;
                            }
                            ?>
                        </tbody>
                    </table>
                </section>
            </div>
            <script type="text/javascript">
                jQuery(function ($) {
                    $('.woo-wallet-importer-done-view-errors').on('click', function (event) {
                        event.preventDefault();
                        $('.woo-wallet-importer-error-log').slideToggle();
                    });
                });

            </script>
            <?php
        }

        public function import() {
            $file = $this->wallet_import_handle_upload();

            if (isset($file['error'])) {
                echo '<section><p><strong>' . __('Sorry, there has been an error.', 'woo-wallet-importer') . '</strong><br />';
                echo esc_html($file['error']) . '</p></section>';
                return false;
            } else if (!file_exists($file['file'])) {
                echo '<section><p><strong>' . __('Sorry, there has been an error.', 'woo-wallet-importer') . '</strong><br />';
                printf(__('The export file could not be found at <code>%s</code>. It is likely that this was caused by a permissions problem.', 'woo-wallet-importer'), esc_html($file['file']));
                echo '</p></section>';
                return false;
            }

            $this->id = (int) $file['id'];
            $this->file = get_attached_file($this->id);
            if (!self::is_file_valid_csv($this->file)) {
                echo '<section><p><strong>';
                _e('Invalid file type. The importer supports CSV and TXT file formats.', 'woo-wallet-importer');
                echo '</p></section>';
                wp_import_cleanup($this->id);
                return false;
            }
            $result = $this->process_posts();
            if (is_wp_error($result)) {
                return $result;
            }
        }

        private function wallet_import_handle_upload() {
            if (!isset($_FILES['import'])) {
                return array(
                    'error' => sprintf(
                            /* translators: 1: php.ini, 2: post_max_size, 3: upload_max_filesize */
                            __('File is empty. Please upload something more substantial. This error could also be caused by uploads being disabled in your %1$s file or by %2$s being defined as smaller than %3$s in %1$s.'),
                            'php.ini',
                            'post_max_size',
                            'upload_max_filesize'
                    ),
                );
            }

            $overrides = array(
                'test_form' => false,
                'test_type' => false,
            );
            $upload = wp_handle_upload($_FILES['import'], $overrides);

            if (isset($upload['error'])) {
                return $upload;
            }

            // Construct the object array.
            $object = array(
                'post_title' => wp_basename($upload['file']),
                'post_content' => $upload['url'],
                'post_mime_type' => $upload['type'],
                'guid' => $upload['url'],
                'context' => 'import',
                'post_status' => 'private',
            );

            // Save the data.
            $id = wp_insert_attachment($object, $upload['file']);

            /*
             * Schedule a cleanup for one day from now in case of failed
             * import or missing wp_import_cleanup() call.
             */
            wp_schedule_single_event(time() + DAY_IN_SECONDS, 'importer_scheduled_cleanup', array($id));

            return array(
                'file' => $upload['file'],
                'id' => $id,
            );
        }

        public static function is_file_valid_csv($file) {
            $valid_filetypes = self::get_valid_csv_filetypes();
            $filetype = wp_check_filetype($file, $valid_filetypes);
            if (in_array($filetype['type'], $valid_filetypes, true)) {
                return true;
            }

            return false;
        }

        protected static function get_valid_csv_filetypes() {
            return array(
                'csv' => 'text/csv',
                'txt' => 'text/plain',
            );
        }

        public function process_posts() {
            wp_enqueue_style('woo-wallet-import-jquery-ui');
            wp_enqueue_script('jquery-ui-progressbar');
            wp_localize_script(
                    'woo_wallet_importer',
                    'woo_wallet_importer_param',
                    array(
                        'ajaxurl' => admin_url('admin-ajax.php'),
                        'import_nonce' => wp_create_nonce('woo-wallet-import'),
                        'file' => $this->file,
                        'delimiter' => WOO_WALLET_IMPORTER_DELIMITER,
                        'import_id' => $this->id
                    )
            );
            wp_enqueue_script('woo_wallet_importer');
            ?>
            <div class="woo-wallet-importer">
                <header>
                    <span class="spinner is-active"></span>
                    <h2><?php _e('Importing', 'woo-wallet-importer'); ?></h2>
                    <p><?php _e('Your transactions are now being imported...', 'woo-wallet-importer'); ?></p>
                </header>
                <section style="padding: 16px;">
                    <div class="woo-wallet-importer-progress"></div>
                </section>
            </div>
            <?php
        }

    }

}

final class WOO_WALLET_IMPORT {

    /**
     * The single instance of the class.
     *
     * @var WOO_WALLET_IMPORT
     * @since 1.0.0
     */
    protected static $_instance = null;

    /**
     * Plugin license API class.
     * @var Woo_Wallet_License
     */
    public $licence = null;

    /**
     * Main instance
     * @return class object
     */
    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Class constructor
     */
    public function __construct() {
        if (Woo_Wallet_Dependencies::is_woo_wallet_active()) {
            $this->define_constants();
            $this->includes();
            $this->init_hooks();
            do_action('woo_wallet_importer_loaded');
        } else {
            add_action('admin_notices', array($this, 'admin_notices'), 15);
        }
    }

    /**
     * Constants define
     */
    private function define_constants() {
        $this->define('WOO_WALLET_IMPORTER_ABSPATH', dirname(__FILE__) . '/');
        $this->define('WOO_WALLET_IMPORTER_PLUGIN_NAME', 'WooWallet Importer');
        $this->define('WOO_WALLET_IMPORTER_PLUGIN_SERVER_URL', 'https://standalonetech.com/');
        $this->define('WOO_WALLET_IMPORTER_PLUGIN_TOKEN', 'woo-wallet-importer');
        $this->define('WOO_WALLET_IMPORTER_VERSION', '1.1.1');
        $this->define('WOO_WALLET_IMPORTER_DELIMITER', ',');
    }

    /**
     * 
     * @param string $name
     * @param mixed $value
     */
    private function define($name, $value) {
        if (!defined($name)) {
            define($name, $value);
        }
    }

    /**
     * Check request
     * @param string $type
     * @return bool
     */
    private function is_request($type) {
        switch ($type) {
            case 'admin' :
                return is_admin();
            case 'ajax' :
                return defined('DOING_AJAX');
            case 'cron' :
                return defined('DOING_CRON');
            case 'frontend' :
                return (!is_admin() || defined('DOING_AJAX') ) && !defined('DOING_CRON');
        }
    }

    /**
     * load plugin files
     */
    public function includes() {
        if ($this->is_request('admin')) {
            include_once(dirname(__FILE__) . '/class-woo-wallet-license.php');
        }
    }

    /**
     * Plugin init
     */
    private function init_hooks() {
        // Set up localisation.
        $this->load_plugin_textdomain();

        add_action('admin_init', array($this, 'admin_init'));

        if ($this->is_request('ajax')) {
            add_action('wp_ajax_woo_wallet_do_ajax_import', array($this, 'woo_wallet_do_ajax_import_callback'));
        }
    }

    public function woo_wallet_do_ajax_import_callback() {
        check_ajax_referer('woo-wallet-import', 'security');
        if (!isset($_POST['file'])) { // PHPCS: input var ok.
            wp_send_json_error(array('message' => __('Insufficient privileges to import.', 'woo-wallet-importer')));
        }

        $params = array(
            'delimiter' => !empty($_POST['delimiter']) ? wc_clean(wp_unslash($_POST['delimiter'])) : ',', // PHPCS: input var ok.
            'start_pos' => isset($_POST['position']) ? absint($_POST['position']) : 2, // PHPCS: input var ok.
            'lines' => apply_filters('woo_wallet_import_batch_size', 20),
            'parse' => true,
            'id' => isset($_POST['import_id']) ? absint($_POST['import_id']) : 0,
            'imported' => isset($_POST['imported']) ? absint($_POST['imported']) : 0,
            'failed' => isset($_POST['failed']) ? absint($_POST['failed']) : 0,
        );
        $messages = get_transient("woo_wallet_import_messages_{$params['id']}") ? get_transient("woo_wallet_import_messages_{$params['id']}") : array();
        $file = wc_clean(wp_unslash($_POST['file'])); // PHPCS: input var ok.

        $h = new WOO_Wallet_Importer_Helper();
        $handle = $h->fopen($file, 'r');
        $total_records_count = count(file($file, FILE_SKIP_EMPTY_LINES));
        $response = array(
            'position' => $params['start_pos'],
            'imported' => $params['imported'],
            'failed' => $params['failed'],
            'percentage' => 0,
            'messages' => $params['messages']
        );

        if ($total_records_count > 0) {
            $header_columns = $h->get_row($file, 1);
            if ($params['lines'] > $total_records_count - 1) {
                $params['lines'] = $total_records_count - 1;
            }
            for ($i = $params['start_pos']; $i < ($params['start_pos'] + $params['lines']); $i++) {
                $row_data = $h->get_row($file, $i);
                if (!$row_data) {
                    continue;
                }
                $email = array_search('email', $header_columns);
                $amount = array_search('amount', $header_columns);
                $details = array_search('details', $header_columns);
                $type = array_search('type', $header_columns);
                $user = apply_filters('woo_wallet_importer_user', get_user_by('email', $row_data[$email]), $row_data[$email]);
                $amount = apply_filters('woo_wallet_importer_amount', floatval($row_data[$amount]), $user, $row_data[$type], $row_data[$email]);
                if ($user && function_exists('woo_wallet')) {
                    $price = wc_price($amount);
                    if ($row_data[$type] == 'debit') {
                        $transaction_id = woo_wallet()->wallet->debit($user->ID, $amount, $row_data[$details]);
                        if ($transaction_id) {
                            $messages[] = __("<strong>{$user->user_email}</strong> wallet has debited with {$price}", 'woo-wallet-importer');
                        } else {
                            $messages[] = __("An error occurred for this transaction (<strong>{$user->user_email}</strong>)", 'woo-wallet-importer');
                        }
                    } else {
                        $transaction_id = woo_wallet()->wallet->credit($user->ID, $amount, $row_data[$details]);
                        if ($transaction_id) {
                            $messages[] = __("<strong>{$user->user_email}</strong> wallet has credited with {$price}", 'woo-wallet-importer');
                        } else {
                            $messages[] = __("An error occurred for this transaction (<strong>{$user->user_email}</strong>)", 'woo-wallet-importer');
                        }
                    }
                } else {
                    $messages[] = __("<strong>{$row_data[$email]}</strong> user does not exist");
                }
                if ($transaction_id) {
                    $response['imported']++;
                } else {
                    $response['failed']++;
                }
                $response['position']++;
            }
        }
        if ($response['position'] >= $total_records_count + 1) {
            $response['position'] = 'done';
            $response['percentage'] = 100;
            $response['url'] = admin_url("admin.php?import=woocommerce-wallet&step=2&import_id={$params['id']}&imported={$response['imported']}&failed={$response['failed']}");
            $h->fclose($handle);
            set_transient("woo_wallet_import_messages_{$params['id']}", $messages, HOUR_IN_SECONDS);
            wp_import_cleanup($params['id']);
        } else {
            $h->fclose($handle);
            set_transient("woo_wallet_import_messages_{$params['id']}", $messages, HOUR_IN_SECONDS);
            $response['percentage'] = absint((($response['position'] - 1) * 100) / ($total_records_count + 1));
        }
        wp_send_json_success($response);
    }

    /**
     * Load Localisation files.
     *
     * Note: the first-loaded translation file overrides any following ones if the same translation is present.
     *
     */
    public function load_plugin_textdomain() {
        $locale = is_admin() && function_exists('get_user_locale') ? get_user_locale() : get_locale();
        $locale = apply_filters('plugin_locale', $locale, 'woo-wallet-importer');

        unload_textdomain('woo-wallet-importer');
        load_textdomain('woo-wallet-importer', WP_LANG_DIR . '/woo-wallet-importer/woo-wallet-importer-' . $locale . '.mo');
        load_plugin_textdomain('woo-wallet-importer', false, plugin_basename(dirname(__FILE__)) . '/languages');
        add_action('admin_enqueue_scripts', array($this, 'admin_scripts'), 10);
    }

    /**
     * Plugin url
     * @return string path
     */
    public function plugin_url() {
        return untrailingslashit(plugins_url('/', __FILE__));
    }

    public function deactivation_hook() {
        woo_wallet_importer()->licence->uninstall();
    }

    /**
     * Display admin notice
     */
    public function admin_notices() {
        echo '<div class="error"><p>';
        _e('WooCommerce Wallet Importer plugin requires <a href="http://wordpress.org/extend/plugins/woo-wallet/">WooCommerce Wallet</a> plugins to be active!', 'woo-wallet-importer');
        echo '</p></div>';
    }

    public function admin_init() {
        /**
         * Importer object for registering the import callback
         * @global Woo_Wallet_Import $woo_wallet_import
         */
        if (defined('WP_LOAD_IMPORTERS')) {
            $csv_importer = new Woo_Wallet_CSV_Import();
            register_importer('woocommerce-wallet', 'WooCommerce Wallet', __('Import <strong>user balance</strong> from a WordPress export file.', 'woo-wallet-importer'), array($csv_importer, 'dispatch'));
        }
        if (get_option('_wallet_settings_extensions_importer_license')) {
            update_option('_wallet_settings_extensions_woo_wallet_importer_license', get_option('_wallet_settings_extensions_importer_license'));
            delete_option('_wallet_settings_extensions_importer_license');
        }
        $plugin = array(
            'plugin_server_url' => WOO_WALLET_IMPORTER_PLUGIN_SERVER_URL,
            'plugin_token' => WOO_WALLET_IMPORTER_PLUGIN_TOKEN,
            'version' => WOO_WALLET_IMPORTER_VERSION
        );
        $this->licence = new Woo_Wallet_License($plugin);
        add_filter('woo_wallet_extensions_settings_sections', array($this, 'woo_wallet_extensions_settings_sections'));
        add_filter('woo_wallet_extensions_settings_filds', array($this, 'woo_wallet_extensions_settings_filds'));
        add_action('update_option__wallet_settings_extensions_woo_wallet_importer_license', array($this, 'extensions_importer_license_check'), 10, 3);
        if (get_option('woo_wallet_importer_license_activated') != 'Activated') {
            add_action('admin_notices', array($this, 'license_inactive_notice'));
        }
    }

    public function license_inactive_notice() {
        if (!current_user_can('manage_options')) {
            return;
        }
        if (isset($_GET['page']) && 'woo-wallet-extensions' == $_GET['page']) {
            return;
        }
        ?>
        <div class="notice notice-error is-dismissible">
            <p><?php printf(__('%sClick here%s to activate WooCommerce Wallet Importer license key to receive updates and support.', 'woo-wallet-importer'), '<a href="' . esc_url(admin_url('admin.php?page=woo-wallet-extensions&activewwtab=_wallet_settings_extensions_woo_wallet_importer_license')) . '">', '</a>'); ?></p>
        </div>
        <?php
    }

    public function woo_wallet_extensions_settings_sections($sections) {
        $sections[] = array(
            'id' => '_wallet_settings_extensions_woo_wallet_importer_license', //'_wallet_settings_extensions_importer_license',
            'title' => __('Importer License', 'woo-wallet-importer'),
            'icon' => 'dashicons-tickets-alt'
        );
        return $sections;
    }

    public function woo_wallet_extensions_settings_filds($settings_fields) {
        $settings_fields['_wallet_settings_extensions_woo_wallet_importer_license'] = array(
            array(
                'name' => 'licence_key',
                'label' => __('API License Key', 'woo-wallet-importer'),
                'desc' => __('Enter License Key', 'woo-wallet-importer'),
                'type' => 'text',
                'default' => ''
            ),
            array(
                'name' => 'license_product_id',
                'label' => __('API Product ID', 'woo-wallet-withdrawal'),
                'desc' => __('Enter License product ID', 'woo-wallet-withdrawal'),
                'type' => 'text',
                'default' => ''
            ),
            array(
                'name' => 'is_activate',
                'label' => __('Deactivate API License Key', 'woo-wallet'),
                'desc' => __('Deactivates an API License Key so it can be used on another blog.', 'woo-wallet'),
                'type' => 'checkbox',
            ),
            array(
                'name' => 'nonce_rand',
                'type' => 'rand'
            )
        );
        return $settings_fields;
    }

    public function extensions_importer_license_check($old_value, $value, $option) {
        if (!empty($value)) {
            $args = array(
                'product_id' => $value['license_product_id'],
                'api_key' => $value['licence_key'],
                'activation_status' => $value['is_activate'] ? $value['is_activate'] : 'off'
            );
            if (!is_null(woo_wallet_importer()->licence)) {
                woo_wallet_importer()->licence->manage_api_license($args);
            }
        }
    }

    public function admin_scripts() {
        global $post;
        $screen = get_current_screen();
        $screen_id = $screen ? $screen->id : '';
        // Register scripts
        wp_register_script('woo_wallet_importer_admin', $this->plugin_url() . '/assets/js/admin.js', array('jquery'), WOO_WALLET_IMPORTER_VERSION, true);
        wp_localize_script('woo_wallet_importer_admin', 'woo_wallet_importer_admin_param', array('import_url' => admin_url('admin.php?import=woocommerce-wallet'), 'title' => __('Import', 'woo-wallet-importer')));
        if (in_array($screen_id, array('toplevel_page_woo-wallet'))) {
            wp_enqueue_script('woo_wallet_importer_admin');
        }
    }

}

// include dependencies file
if (!class_exists('Woo_Wallet_Dependencies')) {
    include_once dirname(__FILE__) . '/class-woo-wallet-dependencies.php';
}

function woo_wallet_importer() {
    return WOO_WALLET_IMPORT::instance();
}

if (Woo_Wallet_Dependencies::is_woo_wallet_active()) {
    $GLOBALS['woo_wallet_importer'] = woo_wallet_importer();
    register_deactivation_hook(__FILE__, array(woo_wallet_importer(), 'deactivation_hook'));
}