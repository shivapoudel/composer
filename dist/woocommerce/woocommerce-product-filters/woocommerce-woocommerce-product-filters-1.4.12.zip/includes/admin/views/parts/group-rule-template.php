<div class="rule-group" data-id="{{data.groupId}}">
	<div class="or-text">
		<span class="text"><?php echo esc_html__( 'or', 'woocommerce-product-filters' ); ?></span>
	</div>
	<table class="rules-table">
		<tbody class="rules-table-body"></tbody>
	</table>
</div>
