<?php

namespace WooCommerce_Product_Filter_Plugin\Admin\Editor\Component;

interface Generates_Panels_Interface {
	public function generate_panels();
}
