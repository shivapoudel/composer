<?php

namespace WooCommerce_Product_Filter_Plugin\Filter\Component;

interface Rendering_Template_Interface {
	public function template_render();
}
