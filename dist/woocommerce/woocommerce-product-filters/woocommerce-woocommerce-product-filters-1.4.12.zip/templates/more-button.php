<div class="wcpf-more-button">
	<div class="wcpf-more-button-inner">
		<i class="wcpf-more-icon"></i>
		<span class="more-text"><?php echo esc_html__( 'Show more', 'woocommerce-product-filters' ); ?></span>
		<span class="less-text"><?php echo esc_html__( 'Show less', 'woocommerce-product-filters' ); ?></span>
	</div>
</div>
